# Instrucciones rápidas para WebIntoApp

1. Comprime toda la carpeta `Confiaventa` en un ZIP (ya incluído aquí como Confiaventa.zip).
2. En WebIntoApp, importa tu ZIP o sube `index.html` como página principal.
3. Prueba en modo navegador y luego genera APK siguiendo WebIntoApp.
4. Asegúrate de que tu firebaseConfig esté correctamente pegado antes de compilar/apk.
